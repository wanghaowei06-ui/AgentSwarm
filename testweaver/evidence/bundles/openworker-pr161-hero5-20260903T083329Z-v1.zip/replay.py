#!/usr/bin/env python3
import hashlib
import json
import sys
import zipfile

def digest(data):
    return hashlib.sha256(data).hexdigest()

def fail(message):
    print("hero bundle replay failed: " + message, file=sys.stderr)
    raise SystemExit(2)

def main():
    if len(sys.argv) != 2:
        fail("usage: replay.py BUNDLE.zip")
    target = sys.argv[1]
    try:
        raw_bundle = open(target, "rb").read()
        with zipfile.ZipFile(target) as archive:
            names = archive.namelist()
            if len(names) != len(set(names)) or "bundle-manifest.json" not in names:
                fail("invalid archive members")
            outer = json.loads(archive.read("bundle-manifest.json"))
            expected = [item["path"] for item in outer["files"]]
            if sorted(name for name in names if name != "bundle-manifest.json") != expected:
                fail("archive allowlist mismatch")
            for item in outer["files"]:
                data = archive.read(item["path"])
                if digest(data) != item["sha256"] or len(data) != item["size"]:
                    fail("outer checksum mismatch: " + item["path"])
            inner = json.loads(archive.read("manifest.json"))
            sums = {}
            for line in archive.read("SHA256SUMS").decode("utf-8").splitlines():
                value, name = line.split("  ", 1)
                if name.startswith("./"):
                    name = name[2:]
                if name in sums:
                    fail("duplicate checksum path")
                sums[name] = value
            expected_sums = set(names) - {"SHA256SUMS", "bundle-manifest.json"}
            if set(sums) != expected_sums:
                fail("inner checksum allowlist mismatch")
            for name, value in sums.items():
                if digest(archive.read(name)) != value:
                    fail("inner checksum mismatch: " + name)
            if outer["classification"] != inner["classification"]:
                fail("classification mismatch")
            if "LIVE" in inner["classification"]:
                fail("unsealed LIVE classification")
            if any(item["status"] == "PASS" for item in inner["observations"].values()):
                fail("PASS is not an evidence observation")
    except (OSError, KeyError, TypeError, ValueError, zipfile.BadZipFile, json.JSONDecodeError) as error:
        fail(str(error))
    print(json.dumps({"bundle_sha256": digest(raw_bundle), "classification": inner["classification"], "replay_equal": True}, sort_keys=True, separators=(",", ":")))

if __name__ == "__main__":
    main()
